			
$(document).ready(function() {

	var params = {
	changedEl: ".cusel-select",
	scrollArrows: false
		}
	cuSel(params);
	
	$('#cat_show').click(function(){
		$('.catalog-list').toggleClass('short');
		if($(this).text() == 'Развернуть список') {
			$(this).text('Свернуть список')}
			
		else {$(this).text('Развернуть список')}
	})
	
	
	$(function() {
		$( "#datepicker" ).datepicker();
	});

	$('#rubrics-slider').jcarousel({
		scroll: 1
    });
	
	$('#inforgaf').jcarousel({
		scroll: 1,
        wrap: 'circular'
    });
	
	$('#partners').jcarousel({
		scroll: 1,
        wrap: 'circular'
    });
	
	$('#vertical-news').jcarousel({
		scroll: 1,
		vertical: true
    });
	
	$('.tabs span').click(function(){
		$(this).parents('.tabs').find('span').removeClass('current');
		$(this).addClass('current');
		$(this).parents('.tabs').next('.tabs-content').children('li').hide();
		$(this).parents('.tabs').next('.tabs-content').children('li:eq('+$(this).parent('li').index()+')').show();
	})
	
	
	// DOM edit
	a = $('.number .link_name').text()
	$('.number').children('li').replaceWith(a);
	
	$('.quotes li').each(function(){
		$('<div class="quote"><i>').appendTo($(this));
		$(this).find('.link_name, .link_intro').appendTo($(this).find('div'))
	})
	
	$('<br />').insertAfter('.tabs-list .link_name');
	$('<br />').insertAfter('.last-comment .link_id_user, .last-comment .link_intro');
	
	$('#cat-rub-hid').remove();
	
	b = $('.news-line').find('li').html()
	$('.news-line').replaceWith('<div class="news-line"><div>'+b+'</div></div>');
	
	// -  бегущая строка
	
	a = $('.news-line').outerWidth();
	run();
	function run(){
		$('.news-line div').css('left', a).animate({left: -a}, 24000, function() {
			run()
		})
	}
	
	
	// active
	i = 1;
	$('.archiveis_item').each(function(){
		i++
		res = ($(this).index()+i)%3 ;
		if(res == 0)
			$(this).css('margin-right', 0)
			
		$(this).find('h3').insertAfter($(this).find('.img1'));
		$(this).find('.filepopup').text('').html('Скачать PDF <i>').insertAfter($(this).find('p'));
		str = $(this).find('p').text();
		str = str.replace(/ /g, '<br />');
		$(this).find('p').html(str);
	})
	
	// articles list
	
	$('.articles-list li').each(function(){
		$(this).children().wrap('<div class="temp-class">');
		$(this).append('<div class="articles-list-content">');
		$('.temp-class').children().appendTo($(this).find('.articles-list-content'));
		$('.temp-class').remove();
		$(this).find('.articles-list-content').find('.link_img1').insertBefore($(this).find('.articles-list-content'));
		
		
			if($(this).find('.img1').attr('src') == '' || $(this).find('.img1').attr('style') == 'display:none;') {
				$(this).parent('.link_img1').remove();
				$('<div class="articles-icons">').insertBefore($(this).find('.link_intro'));
				$(this).find('.articles-list-content').find('.pid, .view, .id_media').appendTo($(this).find('.articles-icons'));
			}
			else {
				$(this).find('.link_img1').wrap('<div class="articles-list-preview">');
				$(this).find('.articles-list-content').find('.pid, .view, .id_media').appendTo($(this).find('.articles-list-preview'));
			}
		
		
		
		

	})
	
	// news
	
	$('.newslist li').each(function(){
		$(this).children().wrap('<div class="temp-class">');
		$(this).append('<div class="newslist-content">');
		$('.temp-class').children().appendTo($(this).find('.newslist-content'));
		$('.temp-class').remove();
		
		$(this).find('.newslist-content').find('.link_img1').insertBefore($(this).find('.newslist-content'));
		
		
			if($(this).find('.img1').attr('src') == '') {
				$(this).parent('.link_img1').remove();
				$('<div class="articles-icons">').insertBefore($(this).find('.link_intro'));
				$(this).find('.newslist-content').find('.pid, .view, .id_media').appendTo($(this).find('.articles-icons'));
			}
			else {
				$(this).find('.link_img1').wrap('<div class="newslist-preview">');
				$(this).find('.newslist-content').find('.pid, .view, .id_media').appendTo($(this).find('.newslist-preview'));
			}
		
	})
	$('.newslist-preview').each(function(){
		if($(this).find('.img1').attr('src') == '')
			$(this).find('.link_img1').replaceWith('<div class="clear" style="height:5px;"></div>')
	});
		
	// full news

	$('.newsdeails li').each(function(){
		$(this).find('.h_2').insertBefore($(this).find('.img3'));
		$(this).find('.date_start').insertBefore($(this).find('.intro'));
	})
	
	// full article

	$('.atricles-details li').each(function(){
		$(this).find('.h_2').insertBefore($(this).find('.img3'));
		$(this).find('.img3').wrap('<div class="article-left-block">');
		$(this).find('.h_2').wrap('<span class="h_2 name" style="overflow:auto;">');
		$(this).find('.h_2').children().removeAttr('class');
		$(this).find('.rubrics a').insertBefore($(this).find('.h_2').children()).wrap('<span class="rubs">&rarr;</span>');
		$(this).find('.issues a').appendTo($(this).find('.date_start'));
		$(this).find('.rubrics, .issues').remove();
		

			$('.player').parents('.text').find($('.atricles-details .author')).insertBefore($(this).find('.atricles-details .text p:last-child'));
	
	})
		
	// contents
	
	$('#contestlist').parents('form').prev('h3').addClass('block-title');
	
	$('.contestblock').children().wrap('<div class="temp-class">');
	$('.contestblock').append('<div class="contestblock-content">');
	$('.temp-class').children().appendTo($(this).find('.contestblock-content'));
	$('.temp-class').remove();
	$('.contestblock-content').find('.img').insertBefore('.contestblock-content');
	$('<div class="contestblock-meta">').insertBefore('.contestblock-content .cdate');
	$('.contestblock-content').find('.cview').appendTo($(this).find('.contestblock-meta'));
	
	// contest
	
	$('.contlist .gtext').each(function(){
		if($(this).find(':radio').attr('style') == 'display:none;')
			$(this).find(':radio').addClass('bl');

		$('<div class="contest-wrapper">').appendTo($(this));
		$(this).find('p').appendTo($(this).find('.contest-wrapper'));
	})
	
	$('.contlist .gimg1').each(function(){
		if($(this).find(':radio').attr('style') == 'display:none;') {
			$(this).find(':radio').addClass('bl');

		}
		$('<div class="contest-wrapper">').appendTo($(this));
		$(this).find('p, img').appendTo($(this).find('.contest-wrapper'));
	})
	
	$('#contestlist').prev('h3').addClass('block-title');
	$('.contestlist .block-title').remove();
	
	
	$('.rating').each(function(){
		$(this).html('<i></i>'+$(this).text())
	})

	//
	
	$('#vertical-news .img1').each(function(){
		if($(this).attr('src') == '')
			$(this).parent('.link_img1').remove();
	})
	
	$('.tabs-list .link_img1 img').each(function(){
		if($(this).attr('src') == '')
			$(this).parent('.link_img1').remove();
	})
	
	$('#rubrics1 .link_img1 img').each(function(){
		if($(this).attr('src') == '')
			$(this).parent('.link_img1').remove();
	})
	
	
	$('mediaview #medialist.photo li h4').each(function(){
		$(this).text($(this).text())
	})
	
	$('.article-left-block img').each(function(){
		if($(this).attr('src') == 'media/admin/nf.jpg')
			$(this).parent().remove();
	})
	
	// sprite
	
	$('.pid, .view, .like, .stat_t2, .stat_t1, #firm_address, .comm, .main-menu li, .subscribe-news, #firm_phone, #firm_rubrics, .cview').each(function(){
		$(this).html('<i></i>'+$(this).html());
	})
	$('#commbuttom, #commbuttom1, #otvet a').each(function(){
		$(this).html('<i></i>'+$(this).text());
	})
	
	$('#showBanner').click(function(){
		$('.banner').toggle();
	})
	
	$('ul.comm').children('i').remove();
	
	$('.poll').find('br').remove();
	
});

