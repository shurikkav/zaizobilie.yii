$(document).ready(function(){
	  $.datepicker.setDefaults(
	        $.extend($.datepicker.regional["ru"])
	  );
	  $(".datepicker").datepicker();
	 //$(".chosen").chosen();
	 
/*	 
	 $("#cat_show").click(function() {
		 if ($(this).text() == "Развернуть список") {
			 $(this).text("Свернуть список");
			 $(".catalog-list").removeClass("short");
		 }
		 else {
			 $(this).text("Развернуть список")
			 $(".catalog-list").addClass("short");
		 }
	 })
	*/ 
	 
	if ($("#catalog").val() == 'catalog') {
		$(".right-column").hide();
	}
	
	 
	$("#select_activity_toggler").click(function() {
		if ($("#select_activity").is('.hidden'))
			$("#select_activity").removeClass("hidden");
		else 
			$("#select_activity").addClass("hidden");
	});
	
});

/*var catalog_forma = "#catalog_form";
$(catalog_forma).submit(function() {
	//alert("Thanks for yousing our filter"); 
	


	return false;
 });*/

function changeRegion(ID) {

	$.ajax({
		//Параметры запрос
		 url: "/?module=catalog&action=list&get_cityes=1",
		 type: "GET",
		 cache:true,
		 data: {data: ID},
		 success: function(data){  
			 $("#id_city").html("<option value=''></option>"+data);
			 $("#id_city").trigger("liszt:updated");
		 }

	}).done(function(data){
		//Код выполняющийся после успешного запроса
		
	});
}

function changeRubric(ID) {
	
	$.ajax({
		//Параметры запрос
		 url: "/?module=catalog&action=list&get_actions=1",
		 type: "GET",
		 cache:true,
		 data: {data: ID},
		 success: function(data){  
			 $("#sub_rubric").html("<option value=''></option>"+data);
			 $("#sub_rubric").trigger("liszt:updated");
		 }

	}).done(function(data){
		//Код выполняющийся после успешного запроса
		
	});
}