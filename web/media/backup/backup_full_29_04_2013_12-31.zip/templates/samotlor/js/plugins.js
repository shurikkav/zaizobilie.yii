// Avoid `console` errors in browsers that lack a console.
if (!(window.console && console.log)) {
    (function() {
        var noop = function() {};
        var methods = ['assert', 'clear', 'count', 'debug', 'dir', 'dirxml', 'error', 'exception', 'group', 'groupCollapsed', 'groupEnd', 'info', 'log', 'markTimeline', 'profile', 'profileEnd', 'markTimeline', 'table', 'time', 'timeEnd', 'timeStamp', 'trace', 'warn'];
        var length = methods.length;
        var console = window.console = {};
        while (length--) {
            console[methods[length]] = noop;
        }
    }());
}

$(function() {
	
	// Ссылки, содержащие линки на mp3, flv, youtube заменяем на плеер
    $('a[href$=flv],a[href$=mp4],a[href$=mp3],a[href$=MP3], a[href*="youtube.com/watch"]').each(function() {
	
	var self = $(this);
	var src = '';
	var title = self.text();
	var href = self.attr('href');	
	var poster = $('img', self);	
	
	// Если видео с картинкой
	if (poster.length > 0) {
	    title = self.attr('title');
	    src = poster.attr('src');
	}
	
	etitle = encodeURIComponent(title);
	
	// Обернуть ссылку в DIV
	self.wrap('<div class="player" />');	
	
	var template = '<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="440" height="280">'+
			    '<param name="movie" value="templates/player/player.swf" />'+
			    '<param name="allowFullScreen" value="true" />'+
			    '<param name="flashvars" value="controlbar=over&file='+href+'&image='+src+'&volume=30&title='+etitle+'" />'+
			    '<!--[if !IE]>-->'+
			    '<object type="application/x-shockwave-flash" data="templates/player/player.swf" width="440" height="280" flashvars="controlbar=over&file='+href+'&image='+src+'&volume=30&title='+etitle+'" allowFullScreen="true">'+
			    '<!--<![endif]-->'+
			    '<p>Для просмотра ролика необходимо установить Flash-плеер</p>'+
			    '<!--[if !IE]>-->'+
			    '</object>'+
			    '<!--<![endif]-->'+
			'</object>';
	self.before(template);
	
	// Добавить подпись после ролика
	self.after('<!--<p>'+title+'</p>-->');
	
	// Удалить ссылку
	//self.remove();
	self.hide();
    });
	
    /**
     * Placeholders - подсказки в полях ввода
     */
    if ($().placeholder) {
        $('input[placeholder], textarea[placeholder]').placeholder();
    }

    /**
     * Collapsorz - сворачивание/разворачивание списков
     */
    if ($().collapsorz) {
        $("ul.collapsorz").collapsorz({
            minimum: 4,
            showText: "Показать все",
            hideText: "Свернуть",
            wrapLink: '<p class="more">'

        });
    }

    /**
     * Datepicker - календарь событий
     */
    if ($.datepicker) {
        $.datepicker.regional['ru'] = {
            closeText: 'Закрыть',
            prevText: 'Предыдущий месяц',
            nextText: 'Следующий месяц',
            currentText: 'Сегодня',
            monthNames: ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'],
            monthNamesShort: ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн', 'Июл', 'Авг', 'Сен', 'Окт', 'Ноя', 'Дек'],
            dayNames: ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'],
            dayNamesShort: ['вск', 'пнд', 'втр', 'срд', 'чтв', 'птн', 'сбт'],
            dayNamesMin: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'],
            weekHeader: 'Нед',
            dateFormat: 'yy-m-d',
            firstDay: 1,
            isRTL: false,
            showMonthAfterYear: false,
            yearSuffix: ''
        };
        $.datepicker.setDefaults($.datepicker.regional['ru']);
        
        // Массив для хранения событий календаря
        events = [];

        var today = new Date();
        datepickerOnChangeMonthYear(today.getFullYear(), today.getMonth() + 1);
        
        $('.datepicker').datepicker({
            inline: true,
            showOtherMonths: true,
            changeMonth: false,
            changeYear: false,
            numberOfMonths: 1,
            yearRange: '2003:' + today.getFullYear(),
            onSelect: datepickerOnSelect,
            onChangeMonthYear: datepickerOnChangeMonthYear,
            beforeShowDay: datepickerOnbeforeShowDay
        });
    }
    
    $("#commbuttom").click(function() {
        commmessage = $("#commmessage").val();
        idc = $("#contid").val();
        codec = $("#commcode").val();
        namec = $("#namec").val();
        emailc = $("#emailc").val();
		namemod = $("#namemod").val();
        $.post("?module=plugins&action=post-"+namemod+"&idc="+idc, {name:namec,email:emailc,message:commmessage,code:codec},function(data) {
            $("#commbuttom").css('display','block');
            $("#commbuttom1").css('display','block');
            $("#commcode").css('display','block');
            $("#captcha").css('display','block');
            $("#commmessagediv").css('display','block');
            if(data) {
                if(data==1) {
                    $("#commbuttom").css('display','none');
                    $("#commbuttom1").css('display','none');
                    $("#commcode").css('display','none');
                    $("#captcha").css('display','none');
                    $("#commmessage").val('');
                    $("#commmessagediv").css('display','none');
                    $("#namecdiv").css('display','none');
                    $("#emailcdiv").css('display','none');
                    $("#commtext").text('Данные отправлены.');
                } else {
                    if(data==2) {
                        $("#commtext").text('Ошибка отправки данных.');
                    }
                    if(data==3) {
                        $("#commtext").text('Не заполнены все поля');
                    }
                    if(data==4) {
                        $("#commtext").text('Слишком большой текст');
                    }
                    if(data==5) {
                        $("#commtext").text('Ошибка в тексте записи');
                    }
                    if(data==6) {
                        $("#commtext").text('Сработала система АнтиСпам');
                    }
                }
                $("#commcode").val('');
                $.post("?module=plugins&action=post-code", {code:codec},function(datacode) {
                    if(datacode) {
                        $("#captcha").html(datacode);
                    }
                });
            }
        });
    });
    
    /*js для выбора архива*/

	if (jQuery().selectBox) {
		$('select.combobox').selectBox();
    }
	$(".h").css('display','none');
	$('#nom_year').change(function() {
	var yearObj = $(this);
	var yearVal = yearObj.val();
	var numberObj = $('#number');
	$.ajax({
	    url: "?module=plugins&action=getnumbers&id="+yearVal,
	    dataType: "json",
            success: function (data, status, request) {
                if (status == "success") { //console.log(data);
                    var len = data.id.length;
                    if (len > 0) {
						numberObj.empty();
						numberObj.selectBox('destroy');
                        for(i = 0; i < len;i++) {		
							numberObj.append('<option value="'+data.id[i]+'">'+data.name[i]+'</option>');
                        }
						numberObj.selectBox();
                    }
                }
            }
        });
    });
    $('#number').change(function() {
	$(this).parent().submit();
	document.location.href="?module=articles&action=list&issues="+$('#number').val()+"&years="+$('#nom_year').val();
    });

	/*
    $("#nom_year").change(function(){
    	$(".cusel-scroll-pane .h").hide();
    	year = $("#nom_year").val();
    	if (year != "0")
    		$(".y"+year).show();
    	 $("#number").val(0);
    });
    $("#number").change(function(){
    	document.location.href="?module=articles&action=list&issues="+$('#number').val();
    });
	*/
			
    /*тут задаем тему номера */    
    $("#topmain h2").first().hide();
    var text =  $("#topmain h2").text();
    var link = $("#topmain h2").parent().attr("href");
    //$(".top-stories h2").first().text($(".top-stories h2").first().text()+": "+text+"");
	$(".top-stories h2").first().text($(".top-stories h2").first().text());
    $(".top-stories h2").first().click(function() {
    	document.location.href=link;
    });
    $("#issues1 li").first().css("display","block");
    $("#issues2 li").eq(0).addClass('active');
    $("#issues2 li").mouseover(function() {
    	num = $('#issues2 li').index(this);
    	$("#issues1 li").hide();
    	$("#issues2 li").removeClass('active');
    	$("#issues1 li").eq(num).show();
    	$("#issues2 li").eq(num).addClass('active');
    });
});

/**
 * Выделить в календаре даты
 */
function datepickerOnbeforeShowDay(date) {
    var pdate = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate();
    if ($.inArray(pdate, events) > -1) {
        return [true, 'selected', 'Посмотреть публикации за выбранную дату'];
    }
    return [false, ''];
}

/**
 * Переход на выбранную дату при клике на
 * дате в календаре
 */
function datepickerOnSelect(text, obj) {
    document.location = "?module=articles&action=list" +"&year=" + obj.selectedYear + "&month=" + (obj.selectedMonth + 1) + "&day=" + obj.selectedDay;
}

/**
 * Заполнить массив датами, послав Ajax-запрос
 * при изменении года или месяца
 */
function datepickerOnChangeMonthYear(year, month) {

    var path = "?module=plugins&action=get-dates&year=" + year + "&month=" + month;

    // Делать запрос синхронно
    $.ajaxSetup({ async: false });

    // Получить данные при помощи JSON
    $.getJSON(path, function(data) {

        // Добавить полученные данные в массив событий
        $.each(data, function(index, value) {
            events.push(value);
        });

    });
}

ymaps.ready(function () {

    // По умолчанию ставим Москву
    var latitude = 0.000000;
    var longitude = 0.000000;
    var geocode = 1;
    var balloon = '';

    

    balloon += '<b>'+$("#firm_name").text()+'</b><Br>';
    balloon += $("#firm_address").text();

    var myMap = new ymaps.Map("YMapsID", {
        center: [55.76, 37.64],
        zoom: 10,
        type: "yandex#map",
        behaviors: ["default", "scrollZoom", "ruler"]
    });

    // Добавить контролы
    myMap.controls.add("mapTools").add("typeSelector");

    // Геокодирование
    if (geocode) {
        ymaps.geocode($("#firm_address").text()).then(function (res) {
            var coordinates = res.geoObjects.get(0).geometry.getCoordinates();
            var myPlacemark = new ymaps.Placemark(
                    coordinates, {
                        iconContent: "1",
                        balloonContent: balloon
                    }, {
                        hideIconOnBalloonOpen: true
                    }
            );
            myMap.geoObjects.add(myPlacemark);

            myMap.panTo(
                coordinates, {
                    flying: true
                }
            );
        });
    } else {
        var myPlacemark = new ymaps.Placemark(
            [latitude, longitude], {
                iconContent: "1",
                balloonContent: balloon
            }, {
                hideIconOnBalloonOpen: true
            }
        );
        myMap.geoObjects.add(myPlacemark);
    }

});